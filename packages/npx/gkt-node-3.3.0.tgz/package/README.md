# gkt — GravityKit CLI (npx)

> The AI-Native Software House in a Box — install via `npx`, no Python required.

## Quick Start

```bash
# Install all skills for all supported IDEs
npx gkt init

# Install for a specific IDE
npx gkt init antigravity
npx gkt init cursor
npx gkt init windsurf
npx gkt init cline
npx gkt init kilocode
npx gkt init copilot
npx gkt init kiro
```

## Commands

| Command | Description |
|---------|-------------|
| `npx gkt init [target]` | Install GravityKit skills & workflows into current directory |
| `npx gkt init [target] --group <name>` | Install a specific skill group |
| `npx gkt groups` | List available skill groups |
| `npx gkt list` | List installed AI Agents (requires `gkt init` first) |
| `npx gkt doctor` | Check environment health (Python, Node, Git, npm) |
| `npx gkt version` | Show current version |
| `npx gkt help` | Show help message |

## Init Targets

### By IDE

| Target | Output Directory | IDE |
|--------|-----------------|-----|
| `all` (default) | All below | All supported IDEs |
| `antigravity` | `.agent/` | Antigravity (Gemini) |
| `cursor` | `.cursor/rules/` | Cursor |
| `windsurf` | `.windsurf/rules/` | Windsurf |
| `cline` | `.clinerules/` | Cline |
| `kilocode` | `.kilocode/rules/` | Kilo Code |
| `copilot` | `.github/instructions/` | GitHub Copilot |
| `kiro` | `.kiro/` | Kiro (skills, hooks, steering, specs) |

### By Skill Group

Instead of installing all 500+ skills, pick a focused group:

```bash
npx gkt init general-dev           # General development
npx gkt init n8n-dev               # n8n workflow development
npx gkt init nocobase-dev          # NocoBase plugin development
npx gkt init security-audit        # Security & pentesting
npx gkt init seo-marketing         # SEO & content marketing

# Combine IDE + group
npx gkt init antigravity --group n8n-dev
npx gkt init all --group general-dev
```

Run `npx gkt groups` to see all available groups with skill/workflow counts.

## How It Works

1. **Downloads** the GravityKit source tarball from GitHub (matching the current version)
2. **Extracts** skills, workflows, and IDE-specific configs
3. **Copies** them into the appropriate directories in your project

No external npm dependencies — uses only Node.js built-ins.

## Requirements

- **Node.js** ≥ 16
- **Internet connection** (downloads assets from GitHub at runtime)

## Also Available via pip

```bash
pip install gkt
gkt init
```

## License

MIT
